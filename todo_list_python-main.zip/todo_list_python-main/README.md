# Class task

Simple program for creating a to do list using Python
